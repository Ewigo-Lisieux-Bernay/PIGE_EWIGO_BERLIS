# Pige-Ewigo-BL

## Déploiement ultra simple sur Render

1. Crée un dépôt GitHub nommé **Pige-Ewigo-BL**
2. Uploade TOUS les fichiers de ce ZIP dans le dépôt
3. Va sur https://render.com
4. New > Web Service > Connect GitHub Repo
5. Sélectionne le dépôt
6. Clique sur Deploy

AUCUNE configuration à faire.
